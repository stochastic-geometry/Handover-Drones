%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Handover Probability in Drone Cellular Networks            %%%
%%%   Authors: Morteza Banagar, Vishnu V. Chetlur, and                  %%%
%%%            Harpreet S. Dhillon                                      %%%
%%%   Emails: mbanagar@vt.edu, vishnucr@vt.edu, hdhillon@vt.edu         %%%
%%%                                                                     %%%
%%%   This code is used to generate the plot of Fig. 1, density of      %%%
%%%   the network of non-serving DBSs for the DSM with Rayleigh         %%%
%%%   distributed speed.                                                %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ClipData1 = 3000;
load('.\Data\Density_RayleighVelocity_Simulation.mat')
load('.\Data\Density_RayleighVelocity_Theory.mat')
Density_Simulation = Density_Simulation(:, 1 : ClipData1);
Density_Theory = Density_Theory(:, 1 : ClipData1);
rVec1 = (1 : ClipData1).';
rVecDS = [100 : 200 : 500, 800, 1000, 1300 : 300 : ClipData1];
MarkerSize = 5;
LineWidth = 2;
h = figure(501);
s1 = gca;
hold on
grid on
box on
plot(rVec1, Density_Theory(1, :).', 'b', 'LineWidth', LineWidth)
plot(rVecDS, Density_Simulation(1, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize, 'MarkerFaceColor', 'w')
plot(rVec1, Density_Theory(2 : 4, :).', 'b', 'LineWidth', LineWidth)
plot(rVecDS, Density_Simulation(2 : 4, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize, 'MarkerFaceColor', 'w')
xlabel('$u_\mathbf{x}$ (m)', 'Interpreter', 'latex', 'FontSize', 14)
ylabel('$\lambda(t; u_\mathbf{x}, u_0)$', 'Interpreter', 'latex', 'FontSize', 14)
set(s1, 'FontName', 'Times', 'FontSize', 14)
legend('Theory', 'Simulation')
legend1 = legend(s1);
set(legend1, 'Location', 'southeast', 'FontSize', 14, 'Interpreter', 'latex')
annotation(h, 'arrow', [0.279 0.168], [0.314 0.867], 'LineWidth', 2);
annotation(h, 'textbox', [0.279 0.300 0.553 0.077], 'String', {'Increasing $t \in \{10, 20, 40, 100\}$ s'}, 'LineStyle', 'none', 'Interpreter', 'latex', 'FontSize', 15, 'FitBoxToText', 'off');
ylim([0, 1.05e-6])
hold off