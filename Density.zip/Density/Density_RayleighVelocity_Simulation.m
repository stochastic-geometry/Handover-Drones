%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Handover Probability in Drone Cellular Networks            %%%
%%%   Authors: Morteza Banagar, Vishnu V. Chetlur, and                  %%%
%%%            Harpreet S. Dhillon                                      %%%
%%%   Emails: mbanagar@vt.edu, vishnucr@vt.edu, hdhillon@vt.edu         %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for Fig. 1,     %%%
%%%   density of the network of non-serving DBSs for the DSM with       %%%
%%%   Rayleigh distributed speed.                                       %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
vMean = 45; % [km/h]
vMean = vMean / 3.6; % [m/s]
vSigma = vMean * sqrt(2 / pi);%muExp = v;%
dr = 1;%10;%
NumR = round((R_UAV - dr) / dr) + 1;
u0 = 500;
tVec = [10, 20, 40, 100];%[20, 100, 300];% Condition: v * t < R_UAV
tLen = length(tVec);
CountPointsAll = zeros(tLen, NumR);
Realizations = 1e6;
tic
parfor i = 1 : Realizations
    CountPoints = zeros(tLen, NumR);
    NumUAV = poissrnd(NumUAV_Initial);
    PosUAV_Range = unifrnd(0, 1, NumUAV, 1);
    PosUAV_Range = R_UAV * sqrt(PosUAV_Range);
    PosUAV_Theta = unifrnd(0, 2 * pi, NumUAV, 1);
    f = PosUAV_Range <= u0;
    PosUAV_Range(f) = [];
    PosUAV_Theta(f) = [];
    NumUAV = length(PosUAV_Range);
    v = raylrnd(vSigma, NumUAV, 1);%exprnd(vMean, NumUAV, 1);%
    PosUAV = repmat(PosUAV_Range, 1, 2) .* [cos(PosUAV_Theta), sin(PosUAV_Theta)];
    DisplacedTheta = unifrnd(0, 2 * pi, NumUAV, 1);
    kk = 0;
    for t = tVec
        kk = kk + 1;
        vd = repmat(v, 1, 2) * t .* [cos(DisplacedTheta), sin(DisplacedTheta)];
        DisplacedPosUAV = PosUAV + vd;
        NewRange = sqrt(sum(DisplacedPosUAV .^ 2, 2));
        SlottedRange = ceil(NewRange / dr);
        [a, b] = hist(SlottedRange, unique(SlottedRange));
        CountPoints(kk, b) = a;
    end
    CountPoints = CountPoints(:, 1 : NumR);
    CountPointsAll = CountPointsAll + CountPoints;
end
toc
AreaAnnulus = pi * (2 * (0 : dr : R_UAV - dr) * dr + dr ^ 2);
CountPointsAll = CountPointsAll / Realizations;
Density_Simulation = CountPointsAll ./ repmat(AreaAnnulus, tLen, 1);
save('Density_RayleighVelocity_Simulation', 'Density_Simulation')
datetime('now')