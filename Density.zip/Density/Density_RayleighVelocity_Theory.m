%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Handover Probability in Drone Cellular Networks            %%%
%%%   Authors: Morteza Banagar, Vishnu V. Chetlur, and                  %%%
%%%            Harpreet S. Dhillon                                      %%%
%%%   Emails: mbanagar@vt.edu, vishnucr@vt.edu, hdhillon@vt.edu         %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for Fig. 1,    %%%
%%%   density of the network of non-serving DBSs for the DSM with       %%%
%%%   Rayleigh distributed speed.                                       %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
vMean = 45; % [km/h]
vMean = vMean / 3.6; % [m/s]
vSigma = vMean * sqrt(2 / pi);%muExp = v;%
dr = 1;%10;%
NumR = round((R_UAV - dr) / dr) + 1;
u0 = 500;
tVec = [10, 20, 40, 100];%[20, 100, 300];% Condition: v * t < R_UAV
tLen = length(tVec);
fv = @(v1) raylpdf(v1, vSigma);%@(v1) exppdf(v1, muExp);%
Fv = @(v1) raylcdf(v1, vSigma);%@(v1) expcdf(v1, muExp);%
Density_Theory = zeros(tLen, NumR);
kk = 0;
for t = tVec
    kk = kk + 1;
    tic
    for ux = dr : dr : round(R_UAV)
        fun1 = @(vi, u0, ux) fv(vi) .* 1 / pi .* acos((vi .^ 2 * t ^ 2 + ux .^ 2 - u0 .^ 2) ./ (2 * vi * t .* ux));
        A = 1 - Fv(max(0, (u0 - ux) / t));
        B = integral(@(vi) fun1(vi, u0, ux), abs(u0 - ux) / t, (u0 + ux) / t);
        Density_Theory(kk, round(ux / dr)) = lambda0UAV * (A - B);
    end
    toc
end
save('Density_RayleighVelocity_Theory', 'Density_Theory')