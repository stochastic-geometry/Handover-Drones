%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Handover Probability in Drone Cellular Networks            %%%
%%%   Authors: Morteza Banagar, Vishnu V. Chetlur, and                  %%%
%%%            Harpreet S. Dhillon                                      %%%
%%%   Emails: mbanagar@vt.edu, vishnucr@vt.edu, hdhillon@vt.edu         %%%
%%%                                                                     %%%
%%%   This code is used to generate the plot of Fig. 2, handover        %%%
%%%   probability for both mobility scenarios (SSM and DSM).            %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('.\Data\Mobile DBS\Handover_ConstantVelocityDBS_Simulation.mat')
load('.\Data\Mobile DBS\Handover_ConstantVelocityDBS_Theory.mat')
load('.\Data\Mobile DBS\Handover_RayleighVelocityDBS_Simulation.mat')
load('.\Data\Mobile DBS\Handover_RayleighVelocityDBS_Theory.mat')
load('.\Data\Mobile DBS\Handover_Uniform40VelocityDBS_Simulation.mat')
load('.\Data\Mobile DBS\Handover_Uniform40VelocityDBS_Theory.mat')
% load('.\Data\Mobile DBS\Handover_Uniform80VelocityDBS_Simulation.mat')
% load('.\Data\Mobile DBS\Handover_Uniform80VelocityDBS_Theory.mat')
rVec = 1 : 300;
rVecDS = [1 : 10 : 71, 91 : 30 : 271, 300];
MarkerSize = 5;
LineWidth = 2;
h = figure(502);
s1 = gca;
hold on
grid on
box on
plot(rVec, Handover_RayleighDBS_Theory, 'm', 'LineWidth', LineWidth, 'LineStyle', ':')
plot(rVec, Handover_RayleighDBS_Simulation, 'g', 'LineWidth', LineWidth, 'LineStyle', '-')
plot(rVec, Handover_ConstantDBS_Theory, 'b', 'LineWidth', LineWidth, 'LineStyle', '--')
plot(rVecDS, Handover_ConstantDBS_Simulation(rVecDS), 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize, 'MarkerFaceColor', 'w')
plot(rVec, Handover_Uniform40DBS_Theory, 'm', 'LineWidth', LineWidth, 'LineStyle', ':')
plot(rVec, Handover_Uniform40DBS_Simulation, 'g', 'LineWidth', LineWidth, 'LineStyle', '-')
plot(rVec, Handover_ConstantDBS_Theory, 'b', 'LineWidth', LineWidth, 'LineStyle', '--')
plot(rVecDS, Handover_ConstantDBS_Simulation(rVecDS), 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize, 'MarkerFaceColor', 'w')
% plot(rVec, Handover_Uniform80DBS_Theory, 'm', 'LineWidth', LineWidth, 'LineStyle', ':')
% plot(rVec, Handover_Uniform80DBS_Simulation, 'g', 'LineWidth', LineWidth, 'LineStyle', '-')
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 14)
ylabel('${\rm P}[H(t)]$', 'Interpreter', 'latex', 'FontSize', 14)
set(s1, 'FontName', 'Times', 'FontSize', 14)
legend('DSM, Theory (Lower Bound)', 'DSM, Simulation', 'SSM, Theory (Exact)', 'SSM, Simulation')
legend1 = legend(s1);
set(legend1, 'Location', 'southeast', 'FontSize', 14, 'Interpreter', 'latex')
hold off