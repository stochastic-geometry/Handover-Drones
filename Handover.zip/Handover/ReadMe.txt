These codes generate Fig. 2 of [1].
You can run "PlotData_Handover.m" to get the final plot instantly, or you can run the other files to generate the data for the figure.

Please cite [1] if you reuse any part of these codes.

[1] M. Banagar, V. V. Chetlur, and H. S. Dhillon, “Handover probability in drone cellular networks”, IEEE Wireless Communications Letters, vol. 9, no. 7, pp. 933-937, Jul. 2020