%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Handover Probability in Drone Cellular Networks            %%%
%%%   Authors: Morteza Banagar, Vishnu V. Chetlur, and                  %%%
%%%            Harpreet S. Dhillon                                      %%%
%%%   Emails: mbanagar@vt.edu, vishnucr@vt.edu, hdhillon@vt.edu         %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for the        %%%
%%%   constant velocity case (SSM) of Fig. 2.                           %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
dt = 1;
T = 300;
tVec = dt : dt : T;
tLen = length(tVec);
u0Sigma = 1 / sqrt(2 * pi * lambda0UAV);
u0Mean = u0Sigma * sqrt(pi / 2);
fu0 = @(u1) raylpdf(u1, u0Sigma);
Handover_ConstantDBS_Theory = zeros(1, tLen);
parfor it = 1 : tLen
    tic
    t = tVec(it);
    disp(t)
    InnerInt = @(u0, theta0) arrayfun(@(u0, theta0) Fun1(u0, theta0, v, t), u0, theta0);
    fun01 = @(u0, theta0) exp(-2 * pi * lambda0UAV * InnerInt(u0, theta0)) .* exp(-pi * lambda0UAV * (v * t - u0) .^ 2) .* fu0(u0) * 1 / (2 * pi);
    fun02 = @(u0, theta0) exp(-2 * pi * lambda0UAV * InnerInt(u0, theta0)) .* fu0(u0) * 1 / (2 * pi);
    fun1 = @(u0, theta0) arrayfun(@(u0, theta0) fun01(u0, theta0), u0, theta0);
    fun2 = @(u0, theta0) arrayfun(@(u0, theta0) fun02(u0, theta0), u0, theta0);
    q1 = real(integral2(fun1, 0, v * t, 0, 2 * pi));
    q2 = real(integral2(fun2, v * t, 1e4, 0, 2 * pi)); % upper limit of u0 is inf
    q = q1 + q2;
    Handover_ConstantDBS_Theory(it) = 1 - q;
    toc
end
save('Handover_ConstantVelocityDBS_Theory', 'Handover_ConstantDBS_Theory')
datetime('now')
function I = Fun1(u0, theta0, v, t)
R = sqrt(u0 ^ 2 + v ^ 2 * t ^ 2 - 2 * u0 * v * t * cos(theta0));
I = integral(@(ux) ux * 1 / pi .* acos((u0 ^ 2 - ux .^ 2 - v ^ 2 * t ^ 2) ./ (2 * ux * v * t)), abs(v * t - u0), R);
end