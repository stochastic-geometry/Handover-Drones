%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Handover Probability in Drone Cellular Networks            %%%
%%%   Authors: Morteza Banagar, Vishnu V. Chetlur, and                  %%%
%%%            Harpreet S. Dhillon                                      %%%
%%%   Emails: mbanagar@vt.edu, vishnucr@vt.edu, hdhillon@vt.edu         %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for the        %%%
%%%   variable velocity case (DSM, Uniform) of Fig. 2.                  %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e5;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
vMean = 45; % [km/h]
vMean = vMean / 3.6; % [m/s]
vDiff = 40; % [km/h]
vDiff = vDiff / 3.6; % [m/s]
vStart = vMean - vDiff / 2;%(4 - 12 / pi) * vMean;%
vEnd = vMean + vDiff / 2;%(12 / pi - 2) * vMean;%
% vSigma = vMean * sqrt(2 / pi);%muExp = vMean;%
dt = 1;
T = 300;
tVec = dt : dt : T;
tLen = length(tVec);
Realizations = 1e5;
HandoverMat = zeros(Realizations, tLen);
tic
parfor i = 1 : Realizations
    NumUAV = poissrnd(NumUAV_Initial);
    v = unifrnd(vStart, vEnd, NumUAV, 1);%v = raylrnd(vSigma, NumUAV, 1);%exprnd(muExp, NumUAV, 1);%
    PosUAV_Range = unifrnd(0, 1, NumUAV, 1);
    PosUAV_Range = R_UAV * sqrt(PosUAV_Range);
    PosUAV_Theta = unifrnd(0, 2 * pi, NumUAV, 1);
    PosUAV = repmat(PosUAV_Range, 1, 2) .* [cos(PosUAV_Theta), sin(PosUAV_Theta)];
    DisplacedTheta = unifrnd(0, 2 * pi, NumUAV, 1);
    [~, IndMin] = min(PosUAV_Range);
    for ti = 1 : tLen
        t = tVec(ti); %#ok<*PFBNS>
        vd = repmat(v, 1, 2) .* t .* [cos(DisplacedTheta), sin(DisplacedTheta)];
        DisplacedPosUAV = PosUAV + vd;
        NewRange = sqrt(sum(DisplacedPosUAV .^ 2, 2));
        [~, IndMin1] = min(NewRange);
        if IndMin1 ~= IndMin
            HandoverMat(i, ti) = 1;
        end
    end
end
toc
Handover_Uniform40DBS_Theory = mean(HandoverMat);
save('Handover_Uniform40VelocityDBS_Theory', 'Handover_Uniform40DBS_Theory')
% Handover_UniformVelocityUAV80_Simulation = mean(HandoverMat);
% save(['Model1_ConstantMove_Handover_UniformVelocityUAV' num2str(round(vDiff * 3.6)), '_Simulation'], 'Handover_UniformVelocityUAV80_Simulation')
datetime('now')