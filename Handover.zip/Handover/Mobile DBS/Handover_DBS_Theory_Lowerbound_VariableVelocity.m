%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Handover Probability in Drone Cellular Networks            %%%
%%%   Authors: Morteza Banagar, Vishnu V. Chetlur, and                  %%%
%%%            Harpreet S. Dhillon                                      %%%
%%%   Emails: mbanagar@vt.edu, vishnucr@vt.edu, hdhillon@vt.edu         %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for the        %%%
%%%   variable velocity case (DSM, Rayleigh) of Fig. 2.                 %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
vMean = 45; % [km/h]
vMean = vMean / 3.6; % [m/s]
dt = 1;
T = 300;
tVec = dt : dt : T;
tLen = length(tVec);
vSigma = vMean * sqrt(2 / pi);%muExp = vMean;%
u0Sigma = 1 / sqrt(2 * pi * lambda0UAV);
u0Mean = u0Sigma * sqrt(pi / 2);
fv = @(v1) raylpdf(v1, vSigma);%@(v1) exppdf(v1, muExp);%
fu0 = @(u1) raylpdf(u1, u0Sigma);
Handover_RayleighDBS_Theory = zeros(1, tLen);
% Handover_ExponentialDBS_Theory = zeros(1, tLen);
for it = 1 : tLen %%parfor
    tic
    t = tVec(it);
    disp(t)
    InnerInt = @(v, u0, theta0) arrayfun(@(v, u0, theta0) Fun1(v, u0, theta0, t, vSigma), v, u0, theta0);%Fun1(v, u0, theta0, t, muExp), v, u0, theta0);%
    fun0 = @(v, u0, theta0) exp(-2 * pi * lambda0UAV * InnerInt(v, u0, theta0)) .* fv(v) .* fu0(u0) * 1 / (2 * pi);
    fun = @(v, u0, theta0) arrayfun(@(v, u0, theta0) fun0(v, u0, theta0), v, u0, theta0);
    q = real(integral3(fun, 0, 3 * vMean, 0, 3 * u0Mean, 0, 2 * pi, 'AbsTol', 1e-4, 'RelTol', 1e-4)); % Upper limits for v and u0 are inf
    Handover_RayleighDBS_Theory(it) = 1 - q; %%% This gives a lower bound
%     q = real(integral3(fun, 0, inf, 0, 3 * u0Mean, 0, 2 * pi, 'AbsTol', 1e-4, 'RelTol', 1e-4)); % Upper limit for u0 is inf
%     Handover_ExponentialDBS_Theory(it) = 1 - q; %%% This gives a lower bound
    toc
end
save('Handover_RayleighVelocityDBS_Theory', 'Handover_RayleighDBS_Theory')
% save('Handover_ExponentialVelocityDBS_Theory', 'Handover_ExponentialDBS_Theory')
datetime('now')
function I = Fun1(v0, u0, theta0, t, vSigma)%Fun1(v0, u0, theta0, t, muExp)%
fv = @(vi) raylpdf(vi, vSigma);%@(vi) exppdf(vi, muExp);%
Fv = @(vi) raylcdf(vi, vSigma);%@(vi) expcdf(vi, muExp);%
R = sqrt(u0 ^ 2 + v0 ^ 2 * t ^ 2 - 2 * u0 * v0 * t * cos(theta0));
q1 = integral(@(ux) ux .* (1 - Fv((u0 - ux) / t)), 0, R, 'AbsTol', 1e-4, 'RelTol', 1e-4);
q2 = integral2(@(ux, vi) ux .* fv(vi) .* 1 / pi .* acos((vi .^ 2 * t ^ 2 + ux .^ 2 - u0 .^ 2) ./ (2 * vi .* t .* ux)), 0, R, @(ux) abs(u0 - ux) / t, @(ux) (u0 + ux) / t, 'AbsTol', 1e-4, 'RelTol', 1e-4);
I = q1 - q2;
end